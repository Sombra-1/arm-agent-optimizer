AArchTune final evidence bundle
================================

Outcome: no_eligible_candidate

Open report.html directly in a browser; it is self-contained and makes no network requests.
Verify optimization-passport.json with:
  aarchtune passport verify optimization-passport.json
Validate this bundle with:
  aarchtune finalize validate .

No deployment script was generated because this outcome is diagnostic-only.
Use reproduce-evaluation.sh, when present, to repeat the selected evaluation inputs.

This selection is specific to the recorded hardware, runtime binary, model, workload,
generation settings, and quality policy. Performance can vary with system load, page cache,
and thermal conditions.

Privacy: raw model responses remain in the upstream evaluation directory. Review and sanitize
those upstream artifacts before publication. This final bundle does not copy response bodies.
