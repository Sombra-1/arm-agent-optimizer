This evidence comes from one native Arm64 smoke run on an ephemeral,
shared GitHub-hosted runner. It is not a dedicated-server benchmark,
is not a repeatability study, and is insufficient for final median
performance claims. Model weights and raw model responses are excluded.
